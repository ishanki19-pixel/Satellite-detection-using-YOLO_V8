# Object Detection > 2024-10-18 6:06am
https://universe.roboflow.com/ishanki-verma-nfgyj/object-detection-s5qu9

Provided by a Roboflow user
License: CC BY 4.0

